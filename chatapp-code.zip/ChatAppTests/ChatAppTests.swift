//
//  ChatAppTests.swift
//  ChatAppTests
//
//  Created by Kosta Milovanovic on 9/4/25.
//

import XCTest
@testable import ChatApp

final class ChatAppTests: XCTestCase {

    func testExample() throws {
        XCTAssertTrue(true)
    }
}
